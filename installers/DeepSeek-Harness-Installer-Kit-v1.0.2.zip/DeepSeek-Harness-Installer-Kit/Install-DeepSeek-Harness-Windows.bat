@echo off
setlocal
set "KIT=%~dp0"
if not exist "%KIT%Install-DeepSeek-Harness-Windows.ps1" (
  echo Installer component missing: Install-DeepSeek-Harness-Windows.ps1
  pause
  exit /b 2
)
if not exist "%KIT%installer-core.mjs" (
  echo Installer component missing: installer-core.mjs
  pause
  exit /b 2
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%KIT%Install-DeepSeek-Harness-Windows.ps1"
set "RESULT=%ERRORLEVEL%"
if not "%RESULT%"=="0" (echo Installer exited with code %RESULT%. & pause)
exit /b %RESULT%

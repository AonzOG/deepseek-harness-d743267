#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
exec /bin/bash "$SCRIPT_DIR/Install-DeepSeek-Harness-Unix.sh" "$@"

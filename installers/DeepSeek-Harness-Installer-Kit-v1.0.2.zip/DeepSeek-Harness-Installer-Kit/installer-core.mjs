#!/usr/bin/env node
/** DeepSeek Harness source installer engine. Requires the official verified Node 24 runtime. */
import fs from 'node:fs/promises';
import { existsSync } from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import net from 'node:net';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';

export const APP_ID = 'org.aonzog.deepseek-harness.source-installer.v1';
export const SOURCES = Object.freeze({
  official: 'https://github.com/deepseek-ai/deepseek-harness',
  aonzog: 'https://github.com/AonzOG/deepseek-harness-d743267',
});
export const OWNED = Object.freeze([
  'app', 'runtime', 'Launch-DeepSeek-Harness.bat',
  'Launch-DeepSeek-Harness.sh', 'installer-manifest.json', 'logs',
]);
const SHA_RE = /^[0-9a-f]{40}$/;
const CANCEL_MESSAGE = 'Cancellation requested. The current step will finish before stopping.';

export function normalizeSource(input) {
  if (typeof input !== 'string' || !input.trim()) throw Error('A source HTTPS repository URL is required.');
  let url;
  try { url = new URL(input.trim()); } catch { throw Error('Invalid repository URL.'); }
  if (url.protocol !== 'https:' || url.username || url.password || url.search || url.hash || (url.port && url.port !== '443')) {
    throw Error('Repository URL must use HTTPS without credentials, query, fragment or custom port.');
  }
  const host = url.hostname.toLowerCase();
  if (!host.includes('.') || host === 'localhost' || host.endsWith('.local') || net.isIP(host)) {
    throw Error('Public HTTPS Git hosting is required. Local/private network URLs are not supported.');
  }
  const components = url.pathname.replace(/\/$/, '').split('/').filter(Boolean);
  if (components.length < 2 || components.some(part => !/^[a-zA-Z0-9._~-]+$/.test(part)) || components.some(part => part === '..' || part === '.')) {
    throw Error('Enter a repository URL such as https://github.com/owner/repo (nested groups are supported).');
  }
  const tail = components.at(-1).replace(/\.git$/i, '');
  if (!tail || tail === '.' || tail === '..') throw Error('Invalid repository name.');
  components[components.length - 1] = tail;
  return `https://${host}/${components.join('/')}`;
}

export function assertInstallPath(input, platform = process.platform) {
  const mod = platform === 'win32' ? path.win32 : path.posix;
  if (typeof input !== 'string' || !mod.isAbsolute(input)) throw Error('Choose an absolute installation directory.');
  const normalized = mod.normalize(input.trim());
  const p = normalized === mod.parse(normalized).root ? normalized : normalized.replace(/[\\/]$/, '');
  const compare = platform === 'win32' ? s => s.toLowerCase() : s => s;
  const roots = [mod.parse(p).root, platform === 'win32' ? (process.env.SystemRoot || 'C:\\Windows') : '/',
    ...(platform === 'win32' ? ['C:\\Windows', 'C:\\Users', 'C:\\Program Files', 'C:\\Program Files (x86)'] : ['/usr', '/etc', '/opt', '/var', '/home', '/Users', '/root'])];
  if (roots.some(r => { const n = mod.normalize(r); return compare(n === mod.parse(n).root ? n : n.replace(/[\\/]$/, '')) === compare(p); })) {
    throw Error('Refusing an operating-system or drive root as an installation directory.');
  }
  const home = compare(mod.normalize(os.homedir()));
  if (compare(p) === home) throw Error('Refusing to use the entire home directory as an installation directory.');
  if (p.includes('\0') || p.split(/[\\/]/).includes('..')) throw Error('Unsafe installation path.');
  return p;
}

export function validateSourceCheckout(root) {
  const pkgPath = path.join(root, 'package.json');
  if (!existsSync(pkgPath) || !existsSync(path.join(root, 'pnpm-lock.yaml')) ||
      !existsSync(path.join(root, 'pnpm-workspace.yaml')) ||
      !existsSync(path.join(root, 'apps', 'cli')) ||
      !existsSync(path.join(root, 'apps', 'web'))) {
    throw Error('Repository is not a compatible DeepSeek Harness source checkout. Missing workspace, lockfile or applications.');
  }
  return pkgPath;
}

export function validateManifest(m) {
  if (!m || m.id !== APP_ID || m.schema !== 1 || !SHA_RE.test(m.source_sha || '') ||
      !Array.isArray(m.owned_paths) || m.owned_paths.length !== OWNED.length ||
      !OWNED.every((v, i) => m.owned_paths[i] === v)) {
    throw Error('Missing, mismatched or modified installer identity manifest. Refusing destructive operation.');
  }
  normalizeSource(m.source_url);
  return m;
}

async function isSymlinkAnywhere(p) {
  const resolved = path.resolve(p);
  const chunks = resolved.split(path.sep);
  let current = path.parse(resolved).root;
  for (const part of chunks.slice(path.parse(resolved).root.split(path.sep).filter(Boolean).length).filter(Boolean)) {
    current = path.join(current, part);
    try { if ((await fs.lstat(current)).isSymbolicLink()) return true; }
    catch (e) { if (e.code !== 'ENOENT') throw e; }
  }
  return false;
}

async function safeDestination(p) {
  const dest = assertInstallPath(p);
  if (await isSymlinkAnywhere(dest)) throw Error('Symlinks/junctions in the installation path are not accepted.');
  const kit = path.dirname(fileURLToPath(import.meta.url));
  const relative = path.relative(dest, kit);
  const inverse = path.relative(kit, dest);
  const contains = r => r === '' || (!r.startsWith('..' + path.sep) && r !== '..' && !path.isAbsolute(r));
  if (contains(relative) || contains(inverse)) {
    throw Error('Choose a destination that does not contain the installer kit.');
  }
  return dest;
}

async function cancelled(cancelFile) {
  if (cancelFile && existsSync(cancelFile)) throw Error(CANCEL_MESSAGE);
}

async function invoke(exe, args, options = {}) {
  await cancelled(options.cancelFile);
  console.log(`\n> ${path.basename(exe)} ${args.map(a => a.includes(' ') ? JSON.stringify(a) : a).join(' ')}`);
  return await new Promise((resolve, reject) => {
    const child = spawn(exe, args, { cwd: options.cwd, env: options.env || process.env, stdio: 'inherit', windowsHide: true, shell: false });
    child.once('error', reject);
    child.once('close', code => code === 0 ? resolve() : reject(Error(`${path.basename(exe)} exited with code ${code}. Review the log above.`)));
  });
}

async function capture(exe, args, cwd) {
  return await new Promise((resolve, reject) => {
    const child = spawn(exe, args, { cwd, windowsHide: true, shell: false });
    let out = '', err = '';
    child.stdout.on('data', chunk => out += chunk);
    child.stderr.on('data', chunk => err += chunk);
    child.once('error', reject);
    child.once('close', code => code === 0 ? resolve(out.trim()) : reject(Error(`${exe} exited ${code}: ${err.trim()}`)));
  });
}

async function gitCheck() {
  const version = await capture('git', ['--version']);
  const match = /git version (\d+)\.(\d+)/.exec(version);
  if (!match || Number(match[1]) < 2 || (Number(match[1]) === 2 && Number(match[2]) < 26)) {
    throw Error('Git 2.26 or newer is required (https://git-scm.com/downloads).');
  }
  console.log('Git:', version);
}

async function copyNodeHome(nodeHome, root) {
  if (!nodeHome || !path.isAbsolute(nodeHome)) throw Error('A verified, absolute Node runtime path is required.');
  const nodeExe = path.join(nodeHome, process.platform === 'win32' ? 'node.exe' : 'bin/node');
  if (!existsSync(nodeExe)) throw Error('Verified Node executable was not found in the runtime directory.');
  const nodeVersion = await capture(nodeExe, ['--version']);
  if (!/^v24\.\d+\.\d+$/.test(nodeVersion)) throw Error(`Node 24 is required for this installer build; received ${nodeVersion}.`);
  const dest = path.join(root, 'runtime', 'node');
  await fs.mkdir(path.dirname(dest), { recursive: true });
  await fs.cp(nodeHome, dest, { recursive: true, errorOnExist: true, force: false });
  console.log('Verified local Node runtime:', nodeVersion);
  return { nodeVersion, nodeExe: path.join(dest, process.platform === 'win32' ? 'node.exe' : 'bin/node'),
    binDir: path.join(dest, process.platform === 'win32' ? '' : 'bin') };
}

async function checkoutSource(root, remote, exactSha, cancelFile) {
  const app = path.join(root, 'app');
  await fs.mkdir(app, { recursive: true });
  const git = (args) => invoke('git', args, { cwd: app, cancelFile });
  await git(['init', '-q']);
  await git(['remote', 'add', 'origin', remote]);
  // Detached commit checkout records exactly which public source was installed.
  await git(['-c', 'credential.interactive=never', 'fetch', '--no-tags', '--depth=1', 'origin', exactSha || 'HEAD']);
  await git(['checkout', '--detach', '--force', 'FETCH_HEAD']);
  const sha = await capture('git', ['rev-parse', 'HEAD'], app);
  if (!SHA_RE.test(sha) || (exactSha && sha !== exactSha)) throw Error('Fetched revision did not match requested commit.');
  console.log('Source commit:', sha);
  return { sha, app };
}

async function pnpmSetup(root, app, runtime, cancelFile) {
  validateSourceCheckout(app);
  const pkg = JSON.parse(await fs.readFile(path.join(app, 'package.json'), 'utf8'));
  const pinned = /^(pnpm)@(\d+\.\d+\.\d+)$/.exec(pkg.packageManager || '');
  if (!pkg.scripts?.build || !pinned) throw Error('Incompatible source: missing build script or a pinned pnpm version.');
  if (Number(pinned[2].split('.')[0]) < 9 || Number(pinned[2].split('.')[0]) > 11) {
    throw Error('This installer currently supports pinned pnpm versions 9 through 11.');
  }
  const npmCli = path.join(path.dirname(runtime.nodeExe), process.platform === 'win32'
    ? 'node_modules/npm/bin/npm-cli.js' : '../lib/node_modules/npm/bin/npm-cli.js');
  if (!existsSync(npmCli)) throw Error('Official Node runtime did not include npm.');
  const tools = path.join(root, 'runtime', 'tools');
  await fs.mkdir(tools, { recursive: true });
  const env = { ...process.env, PATH: runtime.binDir + path.delimiter + (process.env.PATH || ''),
    COREPACK_ENABLE_AUTO_PIN: '0', npm_config_update_notifier: 'false' };
  await invoke(runtime.nodeExe, [npmCli, 'install', '--prefix', tools, '--no-save', '--ignore-scripts', '--no-audit', '--no-fund', `pnpm@${pinned[2]}`], { env, cancelFile });
  const pnpmPkgDir = path.join(tools, 'node_modules', 'pnpm');
  const pnpmPkg = JSON.parse(await fs.readFile(path.join(pnpmPkgDir, 'package.json'), 'utf8'));
  const pnpmRel = typeof pnpmPkg.bin === 'string' ? pnpmPkg.bin : pnpmPkg.bin?.pnpm;
  if (typeof pnpmRel !== 'string') throw Error('Installed pnpm package did not declare its CLI entry point.');
  const pnpmCli = path.resolve(pnpmPkgDir, pnpmRel);
  if (!pnpmCli.startsWith(pnpmPkgDir + path.sep) || !existsSync(pnpmCli)) throw Error('Unexpected or missing pnpm CLI entry point.');
  await invoke(runtime.nodeExe, [pnpmCli, 'install', '--frozen-lockfile', '--reporter=append-only'], { cwd: app, env, cancelFile });
  await invoke(runtime.nodeExe, [pnpmCli, 'run', 'build'], { cwd: app, env, cancelFile });
  return { pinned: pinned[0], pnpmCliRelative: path.relative(root, pnpmCli).split(path.sep).join('/') };
}

export function launcherContent(platform, pnpmCliRelative) {
  if (!/^runtime\/tools\/node_modules\/pnpm\//.test(pnpmCliRelative) || /[\r\n"'`]/.test(pnpmCliRelative)) {
    throw Error('Unsafe pnpm entry point.');
  }
  if (platform === 'win32') {
    const rel = pnpmCliRelative.replaceAll('/', '\\');
    return `@echo off\r\nsetlocal\r\nset "ROOT=%~dp0"\r\nset "PATH=%ROOT%runtime\\node;%PATH%"\r\ncd /d "%ROOT%app" || exit /b 1\r\n"%ROOT%runtime\\node\\node.exe" "%ROOT%${rel}" dsh web %*\r\nset "CODE=%ERRORLEVEL%"\r\nif not "%CODE%"=="0" (echo DeepSeek Harness exited with %CODE%. & pause)\r\nexit /b %CODE%\r\n`;
  }
  return `#!/usr/bin/env bash\nset -euo pipefail\nROOT="$(cd "$(dirname "${'${BASH_SOURCE[0]}'}")" && pwd -P)"\nexport PATH="$ROOT/runtime/node/bin:$PATH"\ncd "$ROOT/app"\nexec "$ROOT/runtime/node/bin/node" "$ROOT/${pnpmCliRelative}" dsh web "$@"\n`;
}

async function writeInstallMetadata(root, args, sourceSha, runtime, built) {
  const launcher = process.platform === 'win32' ? 'Launch-DeepSeek-Harness.bat' : 'Launch-DeepSeek-Harness.sh';
  await fs.writeFile(path.join(root, launcher), launcherContent(process.platform, built.pnpmCliRelative), { mode: 0o755 });
  const manifest = {
    id: APP_ID, schema: 1, source_url: args.source, source_sha: sourceSha,
    package_manager: built.pinned, node_version: runtime.nodeVersion,
    installed_at: new Date().toISOString(), launcher, owned_paths: OWNED,
    user_data_policy: 'User-level DeepSeek Harness data outside the installation folder is untouched.',
  };
  await fs.writeFile(path.join(root, 'installer-manifest.json'), JSON.stringify(manifest, null, 2) + '\n');
  await fs.mkdir(path.join(root, 'logs'), { recursive: true });
}

async function readManifest(dest) {
  const p = path.join(dest, 'installer-manifest.json');
  if (!existsSync(p)) throw Error('No compatible installation manifest at this directory. No files were removed.');
  const m = validateManifest(JSON.parse(await fs.readFile(p, 'utf8')));
  return m;
}

/**
 * A volume-root install (for example C:\\deepseek-harness) must NOT attempt
 * mkdir(C:\\). On Windows, Node's recursive mkdir on an existing drive root can
 * return EPERM. Build in the user's writable TEMP directory instead, provided
 * it is on the same volume so the final rename remains atomic.
 *
 * Other install paths still stage beside the destination as before. A different
 * drive TEMP cannot be used for the final rename, so fall back to the parent.
 */
export function selectStagingParent(destination, temporaryDir = os.tmpdir(), platform = process.platform) {
  const mod = platform === 'win32' ? path.win32 : path.posix;
  const parent = mod.dirname(destination);
  const volumeRoot = mod.parse(parent).root;
  if (platform !== 'win32' || parent.toLowerCase() !== volumeRoot.toLowerCase()) return parent;
  if (typeof temporaryDir !== 'string' || !mod.isAbsolute(temporaryDir)) return parent;
  const temp = mod.normalize(temporaryDir);
  if (mod.parse(temp).root.toLowerCase() !== volumeRoot.toLowerCase()) return parent;
  // The temporary staging area must not be contained within the destination.
  const relation = mod.relative(destination, temp);
  if (relation === '' || (relation !== '..' && !relation.startsWith('..' + mod.sep) && !mod.isAbsolute(relation))) return parent;
  return temp;
}

async function prepareStagingParent(dest) {
  const parent = path.dirname(dest);
  // Do not create a drive root that already exists. Windows may reject this with EPERM.
  if (parent === path.parse(parent).root) {
    const st = await fs.stat(parent);
    if (!st.isDirectory()) throw Error(`Installation drive root is not a directory: ${parent}`);
  } else {
    await fs.mkdir(parent, { recursive: true });
  }
  const stagingParent = selectStagingParent(dest);
  const st = await fs.stat(stagingParent);
  if (!st.isDirectory()) throw Error(`Installer staging parent is not a directory: ${stagingParent}`);
  return stagingParent;
}

async function installOrRepair(args, repair = false) {
  const dest = await safeDestination(args.destination);
  const existing = existsSync(dest) ? await fs.readdir(dest) : [];
  let oldManifest;
  if (repair) {
    oldManifest = await readManifest(dest);
    args.source = oldManifest.source_url;
  } else if (existing.length) {
    throw Error('Installation directory contains files. Choose an empty directory or use Repair for an existing managed installation.');
  }
  args.source = normalizeSource(args.source);
  await gitCheck();
  const stagingParent = await prepareStagingParent(dest);
  console.log('Installer staging parent:', stagingParent);
  let stage;
  try {
    stage = await fs.mkdtemp(path.join(stagingParent, '.dsh-source-stage-'));
  } catch (err) {
    throw Error(`Could not create a staging directory under ${stagingParent}. Check write permission and free space.`, { cause: err });
  }
  let moved = false;
  try {
    await cancelled(args.cancelFile);
    console.log(`Mode: ${repair ? 'Repair' : 'Install'}; source: ${args.source}; destination: ${dest}`);
    const runtime = await copyNodeHome(args.nodeHome, stage);
    await cancelled(args.cancelFile);
    const { sha, app } = await checkoutSource(stage, args.source, repair ? oldManifest.source_sha : null, args.cancelFile);
    const built = await pnpmSetup(stage, app, runtime, args.cancelFile);
    await writeInstallMetadata(stage, args, sha, runtime, built);
    await cancelled(args.cancelFile);
    if (repair) {
      const backup = `${dest}.repair-backup-${new Date().toISOString().replace(/[:.]/g, '-')}`;
      await fs.rename(dest, backup);
      try { await fs.rename(stage, dest); moved = true; }
      catch (err) { await fs.rename(backup, dest); throw err; }
      console.log('Original installation preserved in:', backup);
    } else {
      if (existsSync(dest)) {
        if ((await fs.readdir(dest)).length) throw Error('Destination changed and is no longer empty.');
        await fs.rmdir(dest);
      }
      await fs.rename(stage, dest);
      moved = true;
    }
    console.log('SUCCESS. Exact installed revision:', sha);
    console.log('Launch with:', path.join(dest, process.platform === 'win32' ? 'Launch-DeepSeek-Harness.bat' : 'Launch-DeepSeek-Harness.sh'));
  } finally {
    if (!moved) {
      await fs.rm(stage, { recursive: true, force: true }).catch(err => console.warn('Unable to clean temporary stage:', err.message));
    }
  }
}

async function uninstall(args) {
  const dest = await safeDestination(args.destination);
  const manifest = await readManifest(dest);
  const doKeep = args.keepCheckout !== 'false';
  console.log('Removing managed installation:', dest);
  console.log('Preserving user-level DeepSeek Harness data and all non-installer-owned files.');
  const app = path.join(dest, 'app');
  if (existsSync(app) && doKeep) {
    const backup = `${dest}.uninstall-source-backup-${new Date().toISOString().replace(/[:.]/g, '-')}`;
    await fs.rename(app, backup);
    console.log('Source checkout saved as:', backup);
  } else if (existsSync(app)) {
    // Require an untouched checkout when caller opted out of the safe source backup.
    const status = await capture('git', ['status', '--porcelain', '--untracked-files=all'], app);
    if (status) throw Error('Source checkout has local modifications. Rerun with source backup enabled.');
    await fs.rm(app, { recursive: true });
  }
  for (const child of OWNED.filter(n => n !== 'app' && n !== 'installer-manifest.json')) {
    const target = path.join(dest, child);
    if (existsSync(target)) await fs.rm(target, { recursive: true, force: false });
  }
  await fs.rm(path.join(dest, 'installer-manifest.json'));
  if (!(await fs.readdir(dest)).length) await fs.rmdir(dest);
  console.log('SUCCESS. Managed installation removed. User data and any backup remain.');
  void manifest;
}

function options(argv) {
  const [action, ...rest] = argv;
  const out = { action, keepCheckout: 'true' };
  for (let i = 0; i < rest.length; i++) {
    const x = rest[i];
    if (!x.startsWith('--') || !rest[i + 1]) throw Error(`Missing value for ${x}.`);
    const key = x.slice(2).replace(/-([a-z])/g, (_, c) => c.toUpperCase());
    out[key] = rest[++i];
  }
  return out;
}

export async function main(argv = process.argv.slice(2)) {
  const args = options(argv);
  if (!['install', 'repair', 'uninstall', 'validate-source'].includes(args.action)) throw Error('Usage: node installer-core.mjs <install|repair|uninstall|validate-source> --destination <absolute path> [--source <https-url>] [--node-home <verified Node 24 directory>]');
  if (args.action === 'validate-source') {
    const pkgPath = validateSourceCheckout(args.destination);
    console.log('Compatible workspace layout:', pkgPath);
  } else if (args.action === 'install') await installOrRepair(args);
  else if (args.action === 'repair') await installOrRepair(args, true);
  else await uninstall(args);
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  main().catch(err => { console.error('ERROR:', err.stack || err.message); process.exitCode = 1; });
}

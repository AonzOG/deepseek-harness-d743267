# Windows native WinForms source installer. Compatible with Windows PowerShell 5.1.
param([switch]$Worker, [string]$ConfigPath)
$ErrorActionPreference = 'Stop'
$Kit = Split-Path -Parent $MyInvocation.MyCommand.Path
$Core = Join-Path $Kit 'installer-core.mjs'
$Official = 'https://github.com/deepseek-ai/deepseek-harness'
$Fork = 'https://github.com/AonzOG/deepseek-harness-d743267'

function Write-InstallerLog([string]$File, [string]$Text) {
    ('[{0}] {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Text) | Add-Content -LiteralPath $File -Encoding UTF8
}
function Test-VerifiedNode([string]$Dir) {
    if (-not $Dir) { return $false }
    $Exe = Join-Path $Dir 'node.exe'
    if (-not (Test-Path -LiteralPath $Exe -PathType Leaf)) { return $false }
    try { return ((& $Exe --version) -match '^v24\.\d+\.\d+$') } catch { return $false }
}
function Get-VerifiedNode([string]$InstallDirectory, [string]$LogPath) {
    $Installed = Join-Path $InstallDirectory 'runtime\node'
    if (Test-VerifiedNode $Installed) {
        Write-InstallerLog $LogPath 'Reusing installed app-local Node 24.'
        return @{ Path = $Installed; Temporary = '' }
    }
    Write-InstallerLog $LogPath 'Downloading official Node 24 runtime from nodejs.org (SHA-256 verified).'
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $Architecture = [Environment]::GetEnvironmentVariable('PROCESSOR_ARCHITECTURE')
    if ($Architecture -ne 'AMD64') { throw 'This Windows installer currently supports Windows x64. On ARM64 use the Web npm route or an architecture-specific build.' }
    $Releases = Invoke-RestMethod -Uri 'https://nodejs.org/dist/index.json' -TimeoutSec 45
    $Release = $Releases | Where-Object { $_.version -match '^v24\.\d+\.\d+$' -and $_.files -contains 'win-x64-zip' } | Select-Object -First 1
    if (-not $Release) { throw 'Could not discover a supported Node 24 x64 release.' }
    $Version = $Release.version
    $FileName = "node-$Version-win-x64.zip"
    $Url = "https://nodejs.org/dist/$Version/$FileName"
    $Hashes = (Invoke-WebRequest -UseBasicParsing -Uri "https://nodejs.org/dist/$Version/SHASUMS256.txt" -TimeoutSec 45).Content
    $HashLine = @($Hashes -split "`n" | Where-Object { $_ -match [regex]::Escape($FileName) + '$' } | Select-Object -First 1)
    if ($HashLine.Count -ne 1 -or $HashLine[0] -notmatch '^([a-fA-F0-9]{64})\s+') { throw 'Vendor SHA-256 record was not found.' }
    $Expected = $Matches[1].ToLowerInvariant()
    $Temp = Join-Path ([IO.Path]::GetTempPath()) ('dsh-verified-node-' + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $Temp -Force | Out-Null
    try {
        $Archive = Join-Path $Temp $FileName
        Invoke-WebRequest -UseBasicParsing -Uri $Url -OutFile $Archive -TimeoutSec 900
        $Actual = (Get-FileHash -LiteralPath $Archive -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($Actual -ne $Expected) { throw 'Node vendor SHA-256 mismatch. Runtime rejected.' }
        Write-InstallerLog $LogPath ("Verified Node $Version archive SHA-256: $Actual")
        Expand-Archive -LiteralPath $Archive -DestinationPath $Temp -Force
        $Node = Join-Path $Temp "node-$Version-win-x64"
        if (-not (Test-VerifiedNode $Node)) { throw 'Verified archive did not contain a valid Node 24 binary.' }
        Remove-Item -LiteralPath $Archive -Force
        return @{ Path = $Node; Temporary = $Temp }
    } catch {
        Remove-Item -LiteralPath $Temp -Recurse -Force -ErrorAction SilentlyContinue
        throw
    }
}

if ($Worker) {
    if (-not (Test-Path -LiteralPath $ConfigPath -PathType Leaf)) { exit 2 }
    $C = Get-Content -LiteralPath $ConfigPath -Raw | ConvertFrom-Json
    $TempDir = ''
    try {
        Write-InstallerLog $C.LogPath ("Action: {0}; destination: {1}" -f $C.Action, $C.Destination)
        if (-not (Test-Path -LiteralPath $Core -PathType Leaf)) { throw 'installer-core.mjs is missing.' }
        $Node = Get-VerifiedNode $C.Destination $C.LogPath
        $TempDir = $Node.Temporary
        $NodeExe = Join-Path $Node.Path 'node.exe'
        $Args = @($Core, $C.Action, '--destination', $C.Destination, '--node-home', $Node.Path, '--cancel-file', $C.CancelFile, '--keep-checkout', $C.KeepCheckout)
        if ($C.Action -eq 'install') { $Args += @('--source', $C.Source) }
        # Windows PowerShell 5.1 wraps native stderr lines in ErrorRecords when
        # 2>&1 is used. Git emits ordinary fetch progress on stderr (e.g. "From
        # https://github.com/..."); ErrorActionPreference=Stop would abort the
        # entire installer before checking the native process exit code.
        # Scope Continue only to the native invocation. Out-File failures still
        # terminate, and a nonzero native exit code still fails the operation.
        $SavedErrorActionPreference = $ErrorActionPreference
        try {
            $ErrorActionPreference = 'Continue'
            & $NodeExe @Args 2>&1 |
                ForEach-Object {
                    if ($_ -is [System.Management.Automation.ErrorRecord]) {
                        $_.Exception.Message
                    } else {
                        [string]$_
                    }
                } | Out-File -LiteralPath $C.LogPath -Append -Encoding utf8 -Width 400 -ErrorAction Stop
            $EngineExitCode = $LASTEXITCODE
        } finally {
            $ErrorActionPreference = $SavedErrorActionPreference
        }
        if ($EngineExitCode -ne 0) { throw "Installation engine exited with code $EngineExitCode. Review the log above." }
        Write-InstallerLog $C.LogPath 'Operation complete.'
        if ($C.Action -ne 'uninstall') {
            $DestLogs = Join-Path $C.Destination 'logs'
            if (Test-Path -LiteralPath $DestLogs) { Copy-Item -LiteralPath $C.LogPath -Destination (Join-Path $DestLogs 'installer-last.log') -Force }
        }
        exit 0
    } catch {
        Write-InstallerLog $C.LogPath ('ERROR: ' + $_.Exception.Message)
        exit 1
    } finally {
        if ($TempDir -and (Test-Path -LiteralPath $TempDir)) { Remove-Item -LiteralPath $TempDir -Recurse -Force -ErrorAction SilentlyContinue }
    }
}

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()
$Form = New-Object System.Windows.Forms.Form
$Form.Text = 'DeepSeek Harness - Installer / Repair / Uninstall'
$Form.Width = 790
$Form.Height = 635
$Form.StartPosition = 'CenterScreen'
$Form.FormBorderStyle = 'FixedDialog'
$Form.MaximizeBox = $false
$Font = New-Object System.Drawing.Font('Segoe UI', 10)
$Form.Font = $Font

function LabelAt([string]$Text, [int]$X, [int]$Y, [int]$W = 680, [int]$H = 28) {
    $Label = New-Object System.Windows.Forms.Label
    $Label.Text = $Text; $Label.Location = New-Object System.Drawing.Point($X, $Y)
    $Label.Size = New-Object System.Drawing.Size($W, $H)
    $Form.Controls.Add($Label)
    return $Label
}
function ButtonAt([string]$Text,[int]$X,[int]$Y,[int]$W=120) {
    $B = New-Object System.Windows.Forms.Button
    $B.Text = $Text; $B.Location = New-Object System.Drawing.Point($X,$Y)
    $B.Size = New-Object System.Drawing.Size($W,35)
    $Form.Controls.Add($B); return $B
}
$Header = LabelAt 'Install DeepSeek Harness from a selected source repository' 18 16 740 28
$Header.Font = New-Object System.Drawing.Font('Segoe UI', 12, [System.Drawing.FontStyle]::Bold)
$ActionLabel = LabelAt 'Choose an operation' 18 55
$Mode = New-Object System.Windows.Forms.ComboBox
$Mode.DropDownStyle = 'DropDownList'; $Mode.Location = New-Object System.Drawing.Point(20,84)
$Mode.Width = 285; [void]$Mode.Items.AddRange(@('Install','Repair','Uninstall'))
$Mode.SelectedIndex = 0; $Form.Controls.Add($Mode)
$SourceLabel = LabelAt 'Choose source repository (Install only)' 18 126
$OfficialRadio = New-Object System.Windows.Forms.RadioButton
$OfficialRadio.Text = '1. Official DeepSeek AI'; $OfficialRadio.Location = New-Object System.Drawing.Point(24,157)
$OfficialRadio.Width = 470; $OfficialRadio.Checked = $true; $Form.Controls.Add($OfficialRadio)
$ForkRadio = New-Object System.Windows.Forms.RadioButton
$ForkRadio.Text = '2. AonzOG fork (source snapshot)'; $ForkRadio.Location = New-Object System.Drawing.Point(24,186)
$ForkRadio.Width = 470; $Form.Controls.Add($ForkRadio)
$CustomRadio = New-Object System.Windows.Forms.RadioButton
$CustomRadio.Text = '3. Paste a compatible HTTPS Git repository URL'; $CustomRadio.Location = New-Object System.Drawing.Point(24,215)
$CustomRadio.Width = 640; $Form.Controls.Add($CustomRadio)
$Url = New-Object System.Windows.Forms.TextBox
$Url.Location = New-Object System.Drawing.Point(36,246); $Url.Width = 705
$Url.Enabled = $false; $Form.Controls.Add($Url)
$PathLabel = LabelAt 'Installation folder (change it with Browse)' 18 289
$Destination = New-Object System.Windows.Forms.TextBox
$Destination.Location = New-Object System.Drawing.Point(20,320)
$Destination.Width = 600; $Destination.Text = 'C:\deepseek-harness'
$Form.Controls.Add($Destination)
$Browse = ButtonAt 'Browse...' 636 317 105
$Info = LabelAt 'Uses Git 2.26+; downloads SHA-256-verified Node 24; installs pinned pnpm; builds source.' 18 365 740 52
$Info.ForeColor = [System.Drawing.Color]::DimGray
$Keep = New-Object System.Windows.Forms.CheckBox
$Keep.Text = 'Keep source checkout as an external backup on Uninstall (recommended)'
$Keep.Checked = $true; $Keep.Location = New-Object System.Drawing.Point(23,409)
$Keep.Width = 735; $Form.Controls.Add($Keep)
$Review = LabelAt '' 18 447 730 55
$Review.ForeColor = [System.Drawing.Color]::DarkSlateBlue
$Log = New-Object System.Windows.Forms.TextBox
$Log.Location = New-Object System.Drawing.Point(20,64)
$Log.Size = New-Object System.Drawing.Size(725,410)
$Log.Multiline = $true; $Log.ScrollBars = 'Vertical'; $Log.ReadOnly = $true
$Log.Font = New-Object System.Drawing.Font('Consolas', 9)
$Log.Visible = $false; $Form.Controls.Add($Log)
$Progress = New-Object System.Windows.Forms.ProgressBar
$Progress.Location = New-Object System.Drawing.Point(20,483)
$Progress.Size = New-Object System.Drawing.Size(725,17)
$Progress.Style = 'Marquee'; $Progress.Visible = $false; $Form.Controls.Add($Progress)
$Back = ButtonAt 'Back' 20 520 110
$Next = ButtonAt 'Next' 502 520 112
$Cancel = ButtonAt 'Cancel' 632 520 112
$CopyLog = ButtonAt 'Copy Log' 151 520 125; $CopyLog.Visible = $false
$Run = ButtonAt 'Run Harness' 310 520 160; $Run.Visible = $false
$Form.AcceptButton = $Next
$Script:Page = 0; $Script:Working = $false; $Script:WorkerProcess = $null
$Script:JobLog = ''; $Script:CancelFile = ''; $Script:JobAction = ''; $Script:LastReadSize = -1
$Script:TempJob = ''

function ShowPage([int]$Page) {
    $Script:Page = $Page
    $Setup = $Page -eq 0
    foreach ($C in @($ActionLabel,$Mode,$SourceLabel,$OfficialRadio,$ForkRadio,$CustomRadio,$Url,$PathLabel,$Destination,$Browse,$Info,$Keep,$Review)) { $C.Visible = $Setup }
    $Log.Visible = -not $Setup
    $Progress.Visible = $Script:Working
    $CopyLog.Visible = -not $Setup
    $Back.Visible = $Setup -and -not $Script:Working
    $Next.Visible = $Setup
    $Cancel.Text = if ($Script:Working) { 'Cancel after step' } elseif ($Setup) { 'Exit' } else { 'Close' }
}
function UpdateSourceControls {
    $Installing = $Mode.SelectedItem -eq 'Install'
    $OfficialRadio.Enabled = $Installing; $ForkRadio.Enabled = $Installing; $CustomRadio.Enabled = $Installing
    $Url.Enabled = $Installing -and $CustomRadio.Checked
    $Keep.Enabled = $Mode.SelectedItem -eq 'Uninstall'
    $Review.Text = if ($Installing) { 'Build scripts from the selected repository will run locally. Select only a trusted fork.' } else { 'Repair uses the recorded commit. Uninstall removes only installer-owned paths; user-level data is preserved.' }
}
$Mode.Add_SelectedIndexChanged({ UpdateSourceControls })
foreach ($Radio in @($OfficialRadio,$ForkRadio,$CustomRadio)) { $Radio.Add_CheckedChanged({ UpdateSourceControls }) }
$Browse.Add_Click({
    $Dialog = New-Object System.Windows.Forms.FolderBrowserDialog
    $Dialog.Description = 'Select installation directory or its existing parent.'
    if (Test-Path -LiteralPath $Destination.Text) { $Dialog.SelectedPath = $Destination.Text }
    elseif (Test-Path -LiteralPath (Split-Path -Parent $Destination.Text)) { $Dialog.SelectedPath = Split-Path -Parent $Destination.Text }
    if ($Dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) { $Destination.Text = $Dialog.SelectedPath }
})
$Back.Add_Click({ ShowPage 0 })
$CopyLog.Add_Click({ if ($JobLog -and (Test-Path -LiteralPath $JobLog)) { [Windows.Forms.Clipboard]::SetText([IO.File]::ReadAllText($JobLog)) } })
$Run.Add_Click({
    $Launcher = Join-Path $Destination.Text 'Launch-DeepSeek-Harness.bat'
    if (Test-Path -LiteralPath $Launcher) { Start-Process -FilePath $Launcher -WorkingDirectory $Destination.Text }
})
$Timer = New-Object System.Windows.Forms.Timer
$Timer.Interval = 700
$Timer.Add_Tick({
    if ($Script:JobLog -and (Test-Path -LiteralPath $Script:JobLog)) {
        try {
            $Length = (Get-Item -LiteralPath $Script:JobLog).Length
            if ($Length -ne $Script:LastReadSize) {
                $Script:LastReadSize = $Length
                $Text = Get-Content -LiteralPath $Script:JobLog -Raw -ErrorAction SilentlyContinue
                if ($Text.Length -gt 50000) { $Text = '--- displaying last 50,000 characters; full log is at ' + $Script:JobLog + "`r`n" + $Text.Substring($Text.Length - 50000) }
                $Log.Text = $Text; $Log.SelectionStart = $Log.TextLength; $Log.ScrollToCaret()
            }
        } catch { }
    }
    if ($Script:Working -and $Script:WorkerProcess -and $Script:WorkerProcess.HasExited) {
        $Timer.Stop(); $Script:Working = $false; $Progress.Visible = $false
        $Result = $Script:WorkerProcess.ExitCode
        $Header.Text = if ($Result -eq 0) { 'Operation complete.' } else { 'Operation failed. Copy or inspect the log.' }
        $Run.Visible = ($Result -eq 0 -and $Script:JobAction -ne 'uninstall')
        $Cancel.Text = 'Close'
        $Cancel.Enabled = $true
        $Form.AcceptButton = $Cancel
        [void][System.Windows.Forms.MessageBox]::Show(
            $(if ($Result -eq 0) { 'Completed successfully.' } else { "Failed (exit code $Result). Full log: $Script:JobLog" }),
            'DeepSeek Harness Installer')
    }
})

$Next.Add_Click({
    if ($Script:Working) { return }
    $ChosenAction = $Mode.SelectedItem.ToString().ToLowerInvariant()
    $SelectedSource = if ($OfficialRadio.Checked) { $Official } elseif ($ForkRadio.Checked) { $Fork } else { $Url.Text.Trim() }
    if ($ChosenAction -eq 'install' -and $CustomRadio.Checked -and $SelectedSource -notmatch '^https://[^/]+/.+/.+') {
        [Windows.Forms.MessageBox]::Show('Enter a complete HTTPS repository URL such as https://github.com/owner/repo.') | Out-Null
        return
    }
    $Dest = $Destination.Text.Trim()
    if (-not [IO.Path]::IsPathRooted($Dest) -or $Dest -match '["<>|?*]') {
        [Windows.Forms.MessageBox]::Show('Choose a valid absolute Windows installation path.') | Out-Null
        return
    }
    $Summary = "Operation: $ChosenAction`nSource: $(if ($ChosenAction -eq 'install') { $SelectedSource } else { '(recorded installation)' })`nDestination: $Dest`n`nInstall and Repair download and execute the selected source's dependency/build scripts. They may require additional native build tools.`n`nContinue?"
    if ([Windows.Forms.MessageBox]::Show($Summary, 'Confirm source installation', 'YesNo', 'Warning') -ne 'Yes') { return }
    $Script:TempJob = Join-Path ([IO.Path]::GetTempPath()) ('dsh-install-job-' + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $Script:TempJob -Force | Out-Null
    $Script:JobLog = Join-Path $Script:TempJob 'install.log'
    $Script:CancelFile = Join-Path $Script:TempJob 'cancel.flag'
    $Script:JobAction = $ChosenAction
    $Script:LastReadSize = -1
    [IO.File]::WriteAllText($Script:JobLog, 'Preparing installation...'+[Environment]::NewLine)
    $ConfigFile = Join-Path $Script:TempJob 'job.json'
    @{ Action = $ChosenAction; Destination = $Dest; Source = $SelectedSource; LogPath = $Script:JobLog;
       CancelFile = $Script:CancelFile; KeepCheckout = $(if ($Keep.Checked) { 'true' } else { 'false' }) } |
       ConvertTo-Json -Depth 4 | Set-Content -LiteralPath $ConfigFile -Encoding UTF8
    $StartInfo = New-Object System.Diagnostics.ProcessStartInfo
    $StartInfo.FileName = 'powershell.exe'
    $StartInfo.Arguments = '-NoProfile -ExecutionPolicy Bypass -File "' + $PSCommandPath + '" -Worker -ConfigPath "' + $ConfigFile + '"'
    $StartInfo.CreateNoWindow = $true
    $StartInfo.UseShellExecute = $false
    try {
        $Script:WorkerProcess = [System.Diagnostics.Process]::Start($StartInfo)
        $Script:Working = $true; $Run.Visible = $false; $Header.Text = 'Installing - live diagnostic log'
        ShowPage 1; $Timer.Start()
    } catch {
        [Windows.Forms.MessageBox]::Show($_.Exception.Message, 'Installer failed to start') | Out-Null
    }
})
$Cancel.Add_Click({
    if ($Script:Working) {
        [IO.File]::WriteAllText($Script:CancelFile,'cancel')
        $Cancel.Enabled = $false
        $Header.Text = 'Cancellation queued (current step will finish)'
        return
    }
    $Form.Close()
})
$Form.Add_FormClosing({
    if ($Script:Working) {
        $_.Cancel = $true
        [Windows.Forms.MessageBox]::Show('Installation is running. Select Cancel after step to stop safely.', 'Installer running') | Out-Null
    }
})
UpdateSourceControls
ShowPage 0
[void]$Form.ShowDialog()

#!/usr/bin/env bash
# Shared macOS/Linux native-dialog launcher for the DeepSeek Harness source installer.
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
CORE="$SCRIPT_DIR/installer-core.mjs"
OFFICIAL='https://github.com/deepseek-ai/deepseek-harness'
FORK='https://github.com/AonzOG/deepseek-harness-d743267'
[[ -f "$CORE" ]] || { printf '%s\n' 'Missing installer-core.mjs; extract the complete installer kit.' >&2; exit 2; }

case "$(uname -s)" in
  Darwin) PLATFORM='mac'; DEFAULT_DEST="$HOME/Library/Application Support/deepseek-harness"; LOG_HOME="$HOME/Library/Logs/DeepSeekHarnessInstaller" ;;
  Linux) PLATFORM='linux'; DEFAULT_DEST="${XDG_DATA_HOME:-$HOME/.local/share}/deepseek-harness"; LOG_HOME="${XDG_STATE_HOME:-$HOME/.local/state}/deepseek-harness-installer" ;;
  *) printf '%s\n' 'This launcher supports macOS and Linux only.' >&2; exit 2 ;;
esac
mkdir -p "$LOG_HOME"
chmod 700 "$LOG_HOME"
LOG_FILE="$LOG_HOME/installer-$(date -u +%Y%m%dT%H%M%SZ)-$$.log"
TEMP_NODE=''
cleanup() { if [[ -n "$TEMP_NODE" && -d "$TEMP_NODE" ]]; then rm -rf -- "$TEMP_NODE"; fi; }
trap cleanup EXIT

ask_entry() {
  local prompt="$1" default="$2" result
  if [[ "$PLATFORM" == mac ]]; then
    # Pass prompt through arguments, not dynamically constructed AppleScript.
    result="$(osascript - "$prompt" "$default" <<'APPLE'
on run argv
  set question to item 1 of argv
  set prefill to item 2 of argv
  return text returned of (display dialog question default answer prefill with title "DeepSeek Harness Installer" buttons {"Cancel", "OK"} default button "OK")
end run
APPLE
)" || return 1
  elif command -v zenity >/dev/null 2>&1; then
    result="$(zenity --entry --title='DeepSeek Harness Installer' --text="$prompt" --entry-text="$default")" || return 1
  elif command -v kdialog >/dev/null 2>&1; then
    result="$(kdialog --inputbox "$prompt" "$default" --title 'DeepSeek Harness Installer')" || return 1
  else
    printf '%s [%s]: ' "$prompt" "$default" >&2
    IFS= read -r result || return 1
    [[ -n "$result" ]] || result="$default"
  fi
  printf '%s' "$result"
}

ask_choice() {
  local prompt="$1" options="$2" result
  if [[ "$PLATFORM" == mac ]]; then
    result="$(osascript - "$prompt" "$options" <<'APPLE'
on run argv
  set question to item 1 of argv
  set rawChoices to item 2 of argv
  set AppleScript's text item delimiters to "|"
  set choices to text items of rawChoices
  set answer to choose from list choices with prompt question with title "DeepSeek Harness Installer" default items {item 1 of choices}
  if answer is false then error number -128
  return item 1 of answer
end run
APPLE
)" || return 1
  elif command -v zenity >/dev/null 2>&1; then
    IFS='|' read -r -a items <<< "$options"
    result="$(zenity --list --title='DeepSeek Harness Installer' --text="$prompt" --column='Select' "${items[@]}" --height=310 --width=680)" || return 1
  elif command -v kdialog >/dev/null 2>&1; then
    IFS='|' read -r -a items <<< "$options"
    local kitems=() item
    for item in "${items[@]}"; do kitems+=("$item" "$item"); done
    result="$(kdialog --menu "$prompt" "${kitems[@]}" --title 'DeepSeek Harness Installer')" || return 1
  else
    local i=1 item n
    IFS='|' read -r -a items <<< "$options"
    printf '%s\n' "$prompt" >&2
    for item in "${items[@]}"; do printf '%s) %s\n' "$i" "$item" >&2; ((i+=1)); done
    printf 'Enter option number [1]: ' >&2
    IFS= read -r n || return 1
    [[ -n "$n" ]] || n=1
    [[ "$n" =~ ^[0-9]+$ && "$n" -ge 1 && "$n" -le "${#items[@]}" ]] || return 1
    result="${items[n-1]}"
  fi
  [[ -n "$result" ]] || return 1
  printf '%s' "$result"
}

notify() {
  local message="$1" kind="${2:-info}"
  printf '\n%s\n' "$message"
  if [[ "$PLATFORM" == mac ]]; then
    osascript - "$message" <<'APPLE' >/dev/null 2>&1 || true
on run argv
  display dialog (item 1 of argv) with title "DeepSeek Harness Installer" buttons {"OK"} default button "OK"
end run
APPLE
  elif command -v zenity >/dev/null 2>&1; then
    if [[ "$kind" == error ]]; then zenity --error --title='DeepSeek Harness Installer' --text="$message" --width=540 || true
    else zenity --info --title='DeepSeek Harness Installer' --text="$message" --width=540 || true; fi
  elif command -v kdialog >/dev/null 2>&1; then
    if [[ "$kind" == error ]]; then kdialog --error "$message" || true; else kdialog --msgbox "$message" || true; fi
  fi
}

if [[ "$PLATFORM" == linux && ! -t 0 ]] && ! command -v zenity >/dev/null 2>&1 && ! command -v kdialog >/dev/null 2>&1; then
  printf '%s\n' 'For the graphical installer install zenity or kdialog; otherwise run from a terminal.' >&2
  exit 2
fi

mode="$(ask_choice 'Choose the operation:' 'Install|Repair|Uninstall')" || exit 0
mode="$(printf '%s' "$mode" | tr '[:upper:]' '[:lower:]')"
source_url="$OFFICIAL"
if [[ "$mode" == install ]]; then
  source_choice="$(ask_choice 'Select the source repository:' '1. Official DeepSeek AI|2. AonzOG fork|3. Custom compatible HTTPS repository URL')" || exit 0
  case "$source_choice" in
    1.*) source_url="$OFFICIAL" ;;
    2.*) source_url="$FORK" ;;
    3.*) source_url="$(ask_entry 'Paste a trusted compatible Git repository HTTPS URL:' 'https://github.com/owner/repo')" || exit 0 ;;
    *) printf '%s\n' 'Unknown source option.' >&2; exit 2 ;;
  esac
fi

destination="$(ask_entry 'Absolute destination directory (new or existing managed install):' "$DEFAULT_DEST")" || exit 0
[[ "$destination" == /* ]] || { notify 'An absolute destination path is required.' error; exit 2; }
keep_checkout='true'
if [[ "$mode" == uninstall ]]; then
  response="$(ask_choice 'Preserve your installed source checkout as an external backup?' 'Yes, preserve source checkout|No, remove clean checkout')" || exit 0
  if [[ "$response" == No,* ]]; then keep_checkout='false'; fi
fi

info="Operation: $mode
Source: $(if [[ "$mode" == install ]]; then printf '%s' "$source_url"; else printf '%s' '(recorded commit)'; fi)
Directory: $destination

This runs dependency and build scripts from the selected source (including forks). Install and Repair require Git 2.26+, internet access and sufficient disk space. Node 24 is downloaded from nodejs.org and SHA-256 verified. Installed user data outside this folder is not deleted."
confirmation="$(ask_choice "$info\n\nContinue?" 'Continue|Cancel')" || exit 0
[[ "$confirmation" == Continue ]] || exit 0

printf '%s\n' "Starting $mode. Live copyable log: $LOG_FILE"
printf '%s\n' "Installer kit: $SCRIPT_DIR"

# Reuse only the compatible app-local runtime; otherwise download a fresh verified official runtime.
node_home="$destination/runtime/node"
if [[ -x "$node_home/bin/node" ]] && [[ "$("$node_home/bin/node" --version 2>/dev/null || true)" =~ ^v24\.[0-9]+\.[0-9]+$ ]]; then
  printf '%s\n' 'Using existing app-local Node 24.' | tee -a "$LOG_FILE"
else
  case "$(uname -m)" in x86_64|amd64) arch=x64 ;; aarch64|arm64) arch=arm64 ;; *) notify 'Unsupported CPU architecture for the official Node runtime.' error; exit 2 ;; esac
  if [[ "$PLATFORM" == mac ]]; then osname=darwin; else osname=linux; fi
  TEMP_NODE="$(mktemp -d)"
  printf '%s\n' 'Discovering official Node.js v24 runtime...' | tee -a "$LOG_FILE"
  curl -fsSL --retry 2 --connect-timeout 20 'https://nodejs.org/dist/index.json' -o "$TEMP_NODE/index.json"
  version="$(grep -m1 -Eo '"version":"v24\.[0-9]+\.[0-9]+"' "$TEMP_NODE/index.json" | cut -d '"' -f 4)"
  [[ "$version" =~ ^v24\.[0-9]+\.[0-9]+$ ]] || { notify 'Unable to resolve official Node 24 release.' error; exit 1; }
  archive="node-$version-$osname-$arch.tar.xz"
  base="https://nodejs.org/dist/$version"
  curl -fsSL --retry 2 --connect-timeout 20 "$base/SHASUMS256.txt" -o "$TEMP_NODE/SHASUMS256.txt"
  expected="$(awk -v filename="$archive" '$2==filename {print $1}' "$TEMP_NODE/SHASUMS256.txt")"
  [[ "$expected" =~ ^[0-9a-fA-F]{64}$ ]] || { notify 'Official SHA-256 record missing for the selected runtime.' error; exit 1; }
  curl -fL --retry 2 --connect-timeout 20 "$base/$archive" -o "$TEMP_NODE/$archive"
  if command -v shasum >/dev/null 2>&1; then actual="$(shasum -a 256 "$TEMP_NODE/$archive" | awk '{print $1}')"
  else actual="$(sha256sum "$TEMP_NODE/$archive" | awk '{print $1}')"; fi
  [[ "$actual" == "$expected" ]] || { notify 'Node vendor SHA-256 verification failed; runtime rejected.' error; exit 1; }
  printf '%s\n' "Node $version vendor archive checksum verified: $actual" | tee -a "$LOG_FILE"
  tar -xJf "$TEMP_NODE/$archive" -C "$TEMP_NODE"
  node_home="$TEMP_NODE/node-$version-$osname-$arch"
  [[ -x "$node_home/bin/node" ]] || { notify 'Verified Node archive did not include the expected executable.' error; exit 1; }
fi

args=("$mode" --destination "$destination" --node-home "$node_home" --keep-checkout "$keep_checkout")
if [[ "$mode" == install ]]; then args+=(--source "$source_url"); fi
if "$node_home/bin/node" "$CORE" "${args[@]}" 2>&1 | tee -a "$LOG_FILE"; then
  if [[ "$mode" != uninstall && -d "$destination/logs" ]]; then cp "$LOG_FILE" "$destination/logs/installer-last.log"; fi
  notify "Successfully completed $mode.\nLog: $LOG_FILE\n\nTo launch, open the Launch-DeepSeek-Harness.sh script in the installation folder."
else
  status=$?
  notify "Installer failed (exit $status). Please inspect the log:\n$LOG_FILE" error
  exit "$status"
fi

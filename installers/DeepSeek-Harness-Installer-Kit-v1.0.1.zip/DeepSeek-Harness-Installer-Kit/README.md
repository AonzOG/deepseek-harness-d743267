# DeepSeek Harness: three-source installer kit

**Installer Kit v1.0.1 (preview, 13 October 2026).** Source-build installer for the **Web UI**, not a prebuilt/signed Electron Desktop installer. Installation requires internet access and Git 2.26+; Windows x64, macOS arm64/x64 and Linux x64/arm64 are supported by the bootstrap scripts, subject to upstream build compatibility. DeepSeek Harness itself is in developer preview.

## Windows `C:\\` drive-root installation repair (v1.0.1)

This version corrects the Windows `EPERM: operation not permitted, mkdir 'C:\\'` error reported when choosing the default `C:\\deepseek-harness` destination. The source-build engine no longer attempts to create an existing drive root. When installing directly under a Windows drive root, staging uses the invoking user's writable TEMP directory **only when on the same volume**, so the final move remains atomic; other destinations continue staging alongside their parent as before. The verified Node download, Git version check, three source options, pinned pnpm and build logic are unchanged.

If Windows also denies the final move into a drive-root destination, choose a user-writable installation folder using **Browse**. Do not disable system protections or run with administrator privileges solely to work around this path handling error. A stopped v1.0 attempt before source checkout/build does not require Repair; rerun **Install** with the updated kit. The Node runtime may be downloaded and verified again.

## Pick one of three sources

| Option | Git repository | Behaviour |
| --- | --- | --- |
| **1 - Official** | `https://github.com/deepseek-ai/deepseek-harness` | Fetches the HEAD of the repository's default branch at install time |
| **2 - AonzOG** | `https://github.com/AonzOG/deepseek-harness-d743267` | Fetches the HEAD of the AonzOG repo at install time; initially copied from `d743267...` |
| **3 - Any compatible imported/forked repo** | Paste its trusted public HTTPS Git URL | Fetches that repo's HEAD at install time, then checks the DeepSeek Harness workspace layout |

**Source is never silently switched.** The exact installed commit is written to `installer-manifest.json`. Repair uses the same URL and exact commit rather than automatically updating it. Selecting option 2 does *not* permanently pin `d743267` as the repo advances; use the recorded manifest for reproducibility. Custom sources may run arbitrary package installation/build scripts—use only trusted forks. The installer accepts public HTTPS Git hosts, including GitHub and compatible GitLab/Gitea-style hosts; private authenticated repos are not supported.

## Launch the installer

1. Download/extract the entire Installer Kit ZIP into one folder; keep the files together.
2. **Windows x64:** double-click `Install-DeepSeek-Harness-Windows.bat`. In its graphical wizard, choose **Install / Repair / Uninstall**, source, folder and follow the progress/log. Default installation folder: `C:\deepseek-harness`. Use **Browse** to change it.
3. **macOS:** double-click `Install-DeepSeek-Harness-macOS.command` after extraction and allow the usual macOS script security prompts if applicable. AppleScript dialogs collect choices; Terminal displays a copyable running log. Do not disable Gatekeeper.
4. **Linux:** execute `./Install-DeepSeek-Harness-Linux.sh`. It uses Zenity or KDialog graphical selectors when installed, otherwise a disclosed terminal fallback; the terminal shows the log.
5. Use `Launch-DeepSeek-Harness.bat` (Windows) or `Launch-DeepSeek-Harness.sh` (macOS/Linux) in the chosen installation directory. This runs the documented `pnpm dsh web` command and launches the local browser Web UI, typically at `http://127.0.0.1:3080`.

Keep the installer kit if you may later need **Repair** or **Uninstall**. Both operations are selected by rerunning the same installer; Repair restores a pinned build by staging a fresh checkout and keeping a full backup of the old install. Uninstall removes only identity-manifest-listed owned files and preserves unrelated files and user-level DeepSeek Harness data. By default it also moves the source checkout to an external backup; turning that off requires a clean tracked Git checkout.

## How it works and prerequisites

- Requires a pre-existing **Git 2.26+**. This installer does not silently install/upgrade Git or system build tools. Git may be obtained from https://git-scm.com/downloads.
- Uses a **Node.js 24** runtime from official `nodejs.org` HTTPS downloads, verifies the vendor SHA-256 and bundles the runtime inside the application folder. Its temporary bootstrap copy is deleted when the installer exits.
- Uses the selected repository's exact `packageManager` pin to install a private pnpm copy inside `runtime/tools` without permanently changing `PATH` or touching the system's Node installation. Pnpm is acquired through npm registry package integrity metadata.
- Runs the repository-documented `pnpm install --frozen-lockfile`, `pnpm run build`, then creates a reusable launcher for `pnpm dsh web`. A large initial checkout/build needs considerable storage, RAM and time; native compilers or Python may be needed by some dependency paths. Build failure is reported in the visible log; it is **not** a successful install.
- Uses a staging folder for installs. Repair builds a staging replacement, swaps it into place only on success, and retains the old installation in an external `*.repair-backup-*` directory. Backups can be large; delete them manually only after confirming that personal work is preserved. The installer itself never wipes them automatically.
- Does not modify `~/.dsh` or other user-level data during Install/Repair/Uninstall. Running the application may create its own user-level configuration/data.
- Windows log is shown live in the wizard with **Copy Log**; after Install or Repair it also saves `logs/installer-last.log`. macOS/Linux logs are copied to `logs/installer-last.log` after success and are retained separately under the user's Logs/State directory for failures.
- Installation is per-user when the selected directory permits it. `C:\deepseek-harness` might require elevated permissions on a locked-down Windows machine; **Browse** to a writable location rather than granting broad administrator privileges.

## Supported vs not yet validated

**Implemented:** three-source selection; input validation; SHA-pinned repair; manifest-backed uninstall; path safety; explicit source backup; app-local Node; pnpm version pin; Windows graphical wizard, macOS AppleScript dialogs, Linux Zenity/KDialog dialogs/CLI fallback; error logs and launch scripts.

**Validation performed for this version:** JavaScript syntax, Bash syntax, 17 unit/guard tests and mocked Install/Repair lifecycle tests under Linux. **Not yet performed:** live download of Node, full DeepSeek Harness dependency installation/build, Windows PowerShell GUI run, native Windows/macOS smoke testing, code signing/notarization, or a complete cross-platform Install → Run → Repair → Uninstall acceptance test. Treat this as a testable source-installer preview, not a certified installer or prebuilt desktop executable.

## Files

- `Install-DeepSeek-Harness-Windows.bat` + `.ps1` — Windows native WinForms wizard and verified Node bootstrap.
- `Install-DeepSeek-Harness-macOS.command` — macOS double-click entry.
- `Install-DeepSeek-Harness-Linux.sh` — Linux entry.
- `Install-DeepSeek-Harness-Unix.sh` — shared macOS/Linux dialogs, download and integrity checks.
- `installer-core.mjs` — common source checkout, pinned build, manifest, repair and uninstall engine.
- `tests/installer-core.test.mjs` — non-network safety and logic checks (`node --test tests/installer-core.test.mjs`).

Source and project acknowledgments: original DeepSeek Harness upstream is MIT-licensed (https://github.com/deepseek-ai/deepseek-harness/blob/master/LICENSE). The installer toolkit is independently authored and does not embed binary app distributions.

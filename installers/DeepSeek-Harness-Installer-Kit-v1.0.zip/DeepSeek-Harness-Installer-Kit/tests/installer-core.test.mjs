import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { existsSync } from 'node:fs';
import { APP_ID, OWNED, SOURCES, normalizeSource, assertInstallPath,
  validateSourceCheckout, validateManifest, launcherContent } from '../installer-core.mjs';
const SCRIPT = path.resolve(import.meta.dirname, '../installer-core.mjs');

function run(args) { return spawnSync(process.execPath, [SCRIPT, ...args], { encoding: 'utf8' }); }
async function temporary(t) {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'dsh-installer-test-'));
  t.after(() => fs.rm(dir, { recursive: true, force: true }));
  return dir;
}

test('known sources and compatible imported Git URLs', () => {
  assert.equal(normalizeSource(SOURCES.official), SOURCES.official);
  assert.equal(normalizeSource(SOURCES.aonzog + '.git'), SOURCES.aonzog);
  assert.equal(normalizeSource('https://gitlab.com/group/subgroup/my-fork.git/'), 'https://gitlab.com/group/subgroup/my-fork');
});
test('dangerous or non-repository URLs are rejected', () => {
  for (const u of [
    'http://github.com/a/b', 'https://user:secret@github.com/a/b',
    'https://localhost/a/b', 'https://127.0.0.1/a/b', 'https://github.com/a/b?token=abc',
    'https://github.com/a', 'https://github.com/a/b#master', 'https://github.com/a/../',
    'javascript:alert(1)', 'https://github.com:444/a/b',
  ]) assert.throws(() => normalizeSource(u), undefined, u);
});
test('windows and unix root directories are disallowed', () => {
  for (const x of ['C:\\', 'C:\\Windows', 'C:\\Program Files', 'C:\\Users']) {
    assert.throws(() => assertInstallPath(x, 'win32'), undefined, x);
  }
  for (const x of ['/', '/opt', '/usr', '/etc', '/home']) {
    assert.throws(() => assertInstallPath(x, 'linux'), undefined, x);
  }
  assert.equal(assertInstallPath('C:\\deepseek-harness', 'win32'), 'C:\\deepseek-harness');
  assert.equal(assertInstallPath('/tmp/deepseek-harness', 'linux'), '/tmp/deepseek-harness');
});
test('manifest ownership is exact and tampering is rejected', () => {
  const base = { id: APP_ID, schema: 1, source_url: SOURCES.official,
    source_sha: 'd743267388641bc76f17c45ce8b4c231aed1d32c', owned_paths: [...OWNED] };
  assert.equal(validateManifest(base).id, APP_ID);
  assert.throws(() => validateManifest({ ...base, owned_paths: ['../../important'] }));
  assert.throws(() => validateManifest({ ...base, source_sha: 'main' }));
  assert.throws(() => validateManifest({ ...base, id: 'another-app' }));
});
test('launchers use local Node and pinned pnpm without shell interpolation', () => {
  const rel = 'runtime/tools/node_modules/pnpm/bin/pnpm.mjs';
  const windows = launcherContent('win32', rel);
  const posix = launcherContent('linux', rel);
  assert.match(windows, /%ROOT%runtime\\node\\node\.exe/);
  assert.match(windows, /dsh web/);
  assert.match(posix, /exec "\$ROOT\/runtime\/node\/bin\/node"/);
  assert.match(posix, /"\$@"/);
  assert.throws(() => launcherContent('linux', '../secrets'));
});
test('checkout compatibility must include pinned workspace layout', async t => {
  const dir = await temporary(t);
  assert.throws(() => validateSourceCheckout(dir));
  await fs.writeFile(path.join(dir, 'package.json'), '{}');
  await fs.writeFile(path.join(dir, 'pnpm-lock.yaml'), '');
  await fs.writeFile(path.join(dir, 'pnpm-workspace.yaml'), '');
  await fs.mkdir(path.join(dir, 'apps/cli'), { recursive: true });
  await fs.mkdir(path.join(dir, 'apps/web'), { recursive: true });
  assert.equal(validateSourceCheckout(dir), path.join(dir, 'package.json'));
  assert.equal(run(['validate-source', '--destination', dir]).status, 0);
});
test('uninstall refuses unrelated folders and does not modify them', async t => {
  const root = await temporary(t);
  const dest = path.join(root, 'unrelated');
  await fs.mkdir(dest);
  await fs.writeFile(path.join(dest, 'important.txt'), 'retain');
  const r = run(['uninstall', '--destination', dest]);
  assert.notEqual(r.status, 0);
  assert.equal(await fs.readFile(path.join(dest, 'important.txt'), 'utf8'), 'retain');
});
test('uninstall preserves source checkout and unrelated files by default', async t => {
  const root = await temporary(t);
  const dest = path.join(root, 'managed');
  await fs.mkdir(path.join(dest, 'app'), { recursive: true });
  await fs.mkdir(path.join(dest, 'runtime'), { recursive: true });
  await fs.mkdir(path.join(dest, 'logs'), { recursive: true });
  await fs.writeFile(path.join(dest, 'app', 'my-changes.txt'), 'retain');
  await fs.writeFile(path.join(dest, 'unrelated.txt'), 'retain');
  await fs.writeFile(path.join(dest, 'Launch-DeepSeek-Harness.sh'), 'launcher');
  await fs.writeFile(path.join(dest, 'installer-manifest.json'), JSON.stringify({
    id: APP_ID, schema: 1, owned_paths: OWNED, source_url: SOURCES.official,
    source_sha: 'd743267388641bc76f17c45ce8b4c231aed1d32c',
  }));
  const result = run(['uninstall', '--destination', dest]);
  assert.equal(result.status, 0, result.stderr);
  assert.equal(await fs.readFile(path.join(dest, 'unrelated.txt'), 'utf8'), 'retain');
  await assert.rejects(fs.access(path.join(dest, 'installer-manifest.json')));
  await assert.rejects(fs.access(path.join(dest, 'runtime')));
  const items = await fs.readdir(root);
  const backup = items.find(x => x.startsWith('managed.uninstall-source-backup-'));
  assert.ok(backup);
  assert.equal(await fs.readFile(path.join(root, backup, 'my-changes.txt'), 'utf8'), 'retain');
});
test('uninstall rejects symlinked directory without following it', async t => {
  const root = await temporary(t);
  const target = path.join(root, 'target');
  const link = path.join(root, 'link');
  await fs.mkdir(target);
  await fs.writeFile(path.join(target, 'protect-me.txt'), 'safe');
  await fs.symlink(target, link, 'dir');
  assert.notEqual(run(['uninstall', '--destination', link]).status, 0);
  assert.equal(await fs.readFile(path.join(target, 'protect-me.txt'), 'utf8'), 'safe');
});

// End-to-end transaction simulation with an isolated local Git/Node/pnpm double.
// No network access and no real source build occurs in this test.
async function mockToolchain(t) {
  const root = await temporary(t);
  const bin = path.join(root, 'fake-bin');
  const nodeHome = path.join(root, 'node-24');
  await fs.mkdir(bin);
  await fs.mkdir(path.join(nodeHome, 'bin'), { recursive: true });
  await fs.mkdir(path.join(nodeHome, 'lib/node_modules/npm/bin'), { recursive: true });
  await fs.writeFile(path.join(nodeHome, 'lib/node_modules/npm/bin/npm-cli.js'), '// mocked npm');
  const mockGit = `#!/usr/bin/env bash
set -euo pipefail
if [[ "$1" == --version ]]; then echo 'git version 2.45.0'; exit; fi
printf '%s\\n' "$*" >> "$MOCK_GIT_LOG"
if [[ "$1" == -c ]]; then shift 2; fi
case "$1" in
  init|remote|fetch) exit 0 ;;
  checkout)
    mkdir -p apps/cli apps/web
    printf '%s' '{"packageManager":"pnpm@11.28.5","scripts":{"build":"echo build"}}' > package.json
    : > pnpm-lock.yaml; : > pnpm-workspace.yaml
    exit 0 ;;
  rev-parse) echo 'd743267388641bc76f17c45ce8b4c231aed1d32c'; exit ;;
  status) if [[ "\${MOCK_DIRTY:-0}" == 1 ]]; then echo ' M user.txt'; fi; exit ;;
esac
exit 2
`;
  // Avoid accidental JS template interpolation of shell variable expansions.
  await fs.writeFile(path.join(bin, 'git'), mockGit, { mode: 0o755 });
  const mockNode = `#!/usr/bin/env bash
set -euo pipefail
if [[ "$1" == --version ]]; then echo v24.12.0; exit; fi
if [[ "$1" == */npm-cli.js ]]; then
  prefix=''
  shift
  while (($#)); do if [[ "$1" == --prefix ]]; then prefix="$2"; break; fi; shift; done
  mkdir -p "$prefix/node_modules/pnpm/bin"
  printf '%s' '{"bin":{"pnpm":"bin/pnpm.mjs"}}' > "$prefix/node_modules/pnpm/package.json"
  : > "$prefix/node_modules/pnpm/bin/pnpm.mjs"
  exit 0
fi
if [[ "$1" == */pnpm.mjs ]]; then
  shift
  if [[ "$1" == run && "$2" == build && "\${MOCK_PNPM_FAIL_BUILD:-0}" == 1 ]]; then exit 5; fi
  exit 0
fi
exit 8
`;
  await fs.writeFile(path.join(nodeHome, 'bin/node'), mockNode, { mode: 0o755 });
  const log = path.join(root, 'mock-git.log');
  await fs.writeFile(log, '');
  return { root, nodeHome, env: { ...process.env, PATH: bin + path.delimiter + process.env.PATH, MOCK_GIT_LOG: log }, log };
}
function runWithEnv(args, env) {
  return spawnSync(process.execPath, [SCRIPT, ...args], { env, encoding: 'utf8' });
}
test('mocked Install -> Repair transaction pins revision and preserves original source', async t => {
  const { root, nodeHome, env, log } = await mockToolchain(t);
  const dest = path.join(root, "path with spaces and apostrophe's deepseek-harness");
  const source = 'https://gitlab.com/my-team/deepseek-harness-fork';
  let r = runWithEnv(['install', '--destination', dest, '--source', source, '--node-home', nodeHome], env);
  assert.equal(r.status, 0, r.stderr + r.stdout);
  const manifest = JSON.parse(await fs.readFile(path.join(dest, 'installer-manifest.json'), 'utf8'));
  assert.equal(manifest.source_url, source);
  assert.equal(manifest.source_sha, 'd743267388641bc76f17c45ce8b4c231aed1d32c');
  assert.equal(manifest.package_manager, 'pnpm@11.28.5');
  assert.ok((await fs.readFile(path.join(dest, 'Launch-DeepSeek-Harness.sh'), 'utf8')).includes('dsh web'));
  await fs.writeFile(path.join(dest, 'app', 'user-changes.txt'), 'preserved by repair');
  r = runWithEnv(['repair', '--destination', dest, '--node-home', nodeHome], env);
  assert.equal(r.status, 0, r.stderr + r.stdout);
  assert.match(await fs.readFile(log, 'utf8'), /fetch --no-tags --depth=1 origin d743267388641bc76f17c45ce8b4c231aed1d32c/);
  const entries = await fs.readdir(root);
  const backup = entries.find(e => e.startsWith(path.basename(dest) + '.repair-backup-'));
  assert.ok(backup);
  assert.equal(await fs.readFile(path.join(root, backup, 'app', 'user-changes.txt'), 'utf8'), 'preserved by repair');
  await assert.rejects(fs.access(path.join(dest, 'app', 'user-changes.txt')));
});
test('failed mocked build never replaces existing destination or leaves installer-owned staging', async t => {
  const { root, nodeHome, env } = await mockToolchain(t);
  const dest = path.join(root, 'failing-dest');
  const r = runWithEnv(['install', '--destination', dest, '--source', SOURCES.official, '--node-home', nodeHome],
    { ...env, MOCK_PNPM_FAIL_BUILD: '1' });
  assert.notEqual(r.status, 0, r.stdout);
  assert.ok(!existsLocal(dest));
  assert.ok(!(await fs.readdir(root)).some(v => v.startsWith('.dsh-source-stage-')));
});
function existsLocal(p) { return existsSync(p); }

test('failed mocked Repair preserves original installation and uncommitted data', async t => {
  const { root, nodeHome, env } = await mockToolchain(t);
  const dest = path.join(root, 'repair-failure');
  let r = runWithEnv(['install', '--destination', dest, '--source', SOURCES.aonzog, '--node-home', nodeHome], env);
  assert.equal(r.status, 0, r.stderr + r.stdout);
  await fs.writeFile(path.join(dest, 'app', 'precious.txt'), 'still here');
  r = runWithEnv(['repair', '--destination', dest, '--node-home', nodeHome],
    { ...env, MOCK_PNPM_FAIL_BUILD: '1' });
  assert.notEqual(r.status, 0);
  assert.equal(await fs.readFile(path.join(dest, 'app', 'precious.txt'), 'utf8'), 'still here');
  assert.equal(JSON.parse(await fs.readFile(path.join(dest, 'installer-manifest.json'), 'utf8')).source_url, SOURCES.aonzog);
});
test('uninstall with backup disabled refuses a modified checkout', async t => {
  const root = await temporary(t);
  const dest = path.join(root, 'dirty-checkout');
  await fs.mkdir(path.join(dest, 'app'), { recursive: true });
  await fs.writeFile(path.join(dest, 'installer-manifest.json'), JSON.stringify({
    id: APP_ID, schema: 1, owned_paths: OWNED, source_url: SOURCES.official,
    source_sha: 'd743267388641bc76f17c45ce8b4c231aed1d32c',
  }));
  const r = runWithEnv(['uninstall', '--destination', dest, '--keep-checkout', 'false'], { ...process.env, MOCK_DIRTY: '1' });
  assert.notEqual(r.status, 0);
  assert.ok(existsSync(path.join(dest, 'installer-manifest.json')));
});
